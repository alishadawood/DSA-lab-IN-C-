#include <iostream>
using namespace std;

struct Player {
    char name[50]; 
    int score;
    Player* next;
    Player* prev;

    Player(const char* playerName, int playerScore) {
        int i = 0;
        while (playerName[i] != '\0') { 
            name[i] = playerName[i];
            i++;
        }
        name[i] = '\0'; 
        score = playerScore;
        next = NULL;
        prev = NULL;
    }
};

class GolfTournament {
private:
    Player* head;
    Player* tail;

public:
    GolfTournament() {
        head = NULL;
        tail = NULL;
    }

    ~GolfTournament() { 
        Player* temp = head;
        while (temp) {
            Player* nextNode = temp->next;
            delete temp;
            temp = nextNode;
        }
    }

    void addPlayer(const char* name, int score) {
        Player* newPlayer = new Player(name, score);

        if (!head || score < head->score) { 
            newPlayer->next = head;
            if (head) head->prev = newPlayer;
            head = newPlayer;
            if (!tail) tail = newPlayer;
        } else {
            Player* temp = head;
            while (temp->next && temp->next->score <= score) {
                temp = temp->next;
            }
            newPlayer->next = temp->next;
            newPlayer->prev = temp;
            if (temp->next) temp->next->prev = newPlayer;
            temp->next = newPlayer;

            if (!newPlayer->next) tail = newPlayer;
        }
    }

    void displayAscending() {
        if (!head) {
            cout << "No players in the list.\n";
            return;
        }
        Player* temp = head;
        cout << "Players (Ascending Order):\n";
        while (temp) {
            cout << "Player: " << temp->name << ", Score: " << temp->score << endl;
            temp = temp->next;
        }
    }

    void displayDescending() {
        if (!tail) {
            cout << "No players in the list.\n";
            return;
        }
        Player* temp = tail;
        cout << "Players (Descending Order):\n";
        while (temp) {
            cout << "Player: " << temp->name << ", Score: " << temp->score << endl;
            temp = temp->prev;
        }
    }

    void displayLowestScore() {
        if (!head) {
            cout << "No players in the list.\n";
            return;
        }
        cout << "Lowest Score: " << head->name << ", Score: " << head->score << endl;
    }

    void displayPlayersWithSameScore(int score) {
        Player* temp = head;
        bool found = false;
        while (temp) {
            if (temp->score == score) {
                if (!found) {
                    cout << "Players with score " << score << ":\n";
                    found = true;
                }
                cout << temp->name << endl;
            }
            temp = temp->next;
        }
        if (!found) {
            cout << "No players found with score " << score << ".\n";
        }
    }

    void displayBackwardFromPlayer(const char* name) {
        Player* temp = head;
        while (temp) {
            int i = 0;
            while (name[i] == temp->name[i] && name[i] != '\0' && temp->name[i] != '\0') {
                i++;
            }
            if (name[i] == '\0' && temp->name[i] == '\0') {
                break;
            }
            temp = temp->next;
        }

        if (!temp) {
            cout << "Player not found in the list.\n";
            return;
        }
        cout << "Players behind " << name << ":\n";
        while (temp) {
            cout << "Player: " << temp->name << ", Score: " << temp->score << endl;
            temp = temp->prev;
        }
    }
};

int main() {
    GolfTournament tournament;
    int choice;

    while (true) {
        cout << "\n1. Add New Player\n";
        cout << "2. Display Players (Ascending Order)\n";
        cout << "3. Display Players (Descending Order)\n";
        cout << "4. Display Player with Lowest Score\n";
        cout << "5. Display Players with Same Score\n";
        cout << "6. Display Players Backward from a Given Player\n";
        cout << "7. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;
        cin.ignore(); 

        switch (choice) {
            case 1: {
                char name[50];
                int score;
                cout << "Enter Player Name: ";
                cin.getline(name, 50);
                cout << "Enter Player Score: ";
                cin >> score;
                cin.ignore(); 
                tournament.addPlayer(name, score);
                break;
            }
            case 2:
                tournament.displayAscending();
                break;
            case 3:
                tournament.displayDescending();
                break;
            case 4:
                tournament.displayLowestScore();
                break;
            case 5: {
                int score;
                cout << "Enter score to search: ";
                cin >> score;
                cin.ignore(); 
                tournament.displayPlayersWithSameScore(score);
                break;
            }
            case 6: {
                char name[50];
                cout << "Enter Player Name: ";
                cin.getline(name, 50);
                tournament.displayBackwardFromPlayer(name);
                break;
            }
            case 7:
                cout << "Exiting...\n";
                return 0;
            default:
                cout << "Invalid choice! Try again.\n";
        }
    }

    return 0;
}

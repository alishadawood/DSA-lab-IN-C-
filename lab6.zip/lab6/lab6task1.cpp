#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
    Node* prv;
};


Node* createNode(int data) {
    Node* newNode = new Node();
    newNode->data = data;
    newNode->next = NULL;
    newNode->prv = NULL;
    return newNode;
}

void insertNode(Node*& head, int value) {
    Node* newNode = createNode(value);
    if (head == NULL) {
        head = newNode;
        return;
    }
    Node* temp = head;
    while (temp->next != NULL) {
        temp = temp->next;
    }
    temp->next = newNode;
    newNode->prv = temp;
}

void deleteAtBeginning(Node*& head) {
    if (head == NULL) {
        cout << "List is empty." << endl;
        return;
    }
    Node* temp = head;
    head = head->next;
    if (head != NULL) {
        head->prv = NULL;
    }
    delete temp;
}

void deleteAtPosition(Node*& head, int pos) {
    if (head == NULL) {
        cout << "List is empty." << endl;
        return;
    }

    if (pos == 0) {
        deleteAtBeginning(head);
        return;
    }

    Node* temp = head;
    int i = 0;

    while (temp != NULL && i < pos) {
        temp = temp->next;
        i++;
    }

    if (temp == NULL) {
        cout << "Position out of bounds." << endl;
        return;
    }

    if (temp->prv != NULL)
        temp->prv->next = temp->next;

    if (temp->next != NULL)
        temp->next->prv = temp->prv;

    delete temp;
}

void displayList(Node* head) {
    Node* temp = head;
    while (temp != NULL) {
        cout << temp->data << " -> ";
        temp = temp->next;
    }
    cout << "NULL" << endl;
}

int main() {
    Node* head = NULL;

    insertNode(head, 1);
    insertNode(head, 45);
    insertNode(head, 60);
    insertNode(head, 12);

    cout << "Original list:" << endl;
    displayList(head);

    cout << "Delete at beginning:" << endl;
    deleteAtBeginning(head);
    displayList(head);

    cout << "Delete at position 0:" << endl;
    deleteAtPosition(head, 0); 
    displayList(head);

    return 0;
}

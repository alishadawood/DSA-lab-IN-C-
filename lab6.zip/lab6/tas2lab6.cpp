#include <iostream>
using namespace std;

struct Node {
    string name;
    int score;
    Node* next;
    Node* prev;

    Node(string n, int s) {
        name = n;
        score = s;
        next = NULL;
        prev = NULL;
    }
};

Node* head = NULL;
void addPlayer(string name, int score) {
    Node* newNode = new Node(name, score);

    if (head == NULL || score < head->score) {
        newNode->next = head;
        if (head != NULL) head->prev = newNode;
        head = newNode;
        return;
    }

    Node* temp = head;
    while (temp->next != NULL && temp->next->score <= score) {
        temp = temp->next;
    }

    newNode->next = temp->next;
    newNode->prev = temp;

    if (temp->next != NULL) temp->next->prev = newNode;
    temp->next = newNode;
}

void deletePlayer(string name) {
    Node* temp = head;

    while (temp != NULL && temp->name != name) {
        temp = temp->next;
    }

    if (temp == NULL) {
        cout << "Player not found.\n";
        return;
    }

    if (temp->prev != NULL) temp->prev->next = temp->next;
    else head = temp->next;

    if (temp->next != NULL) temp->next->prev = temp->prev;

    delete temp;
    cout << "Player deleted.\n";
}


void displayAll() {
    Node* temp = head;
    if (temp == NULL) {
        cout << "No players in the list.\n";
        return;
    }
    cout << "Players:\n";
    while (temp != NULL) {
        cout << temp->name << " - " << temp->score << endl;
        temp = temp->next;
    }
}

void displayLowestScore() {
    if (head == NULL) {
        cout << "List is empty.\n";
        return;
    }
    cout << "Lowest Score: " << head->name << " - " << head->score << endl;
}


void displaySameScore(int score) {
    Node* temp = head;
    bool found = false;
    while (temp != NULL) {
        if (temp->score == score) {
            cout << temp->name << " - " << temp->score << endl;
            found = true;
        }
        temp = temp->next;
    }
    if (!found) cout << "No players with score " << score << endl;
}


void displayBackwardFrom(string name) {
    Node* temp = head;
    while (temp != NULL && temp->name != name) {
        temp = temp->next;
    }

    if (temp == NULL) {
        cout << "Player not found.\n";
        return;
    }

    cout << "Backward from " << name << ":\n";
    while (temp != NULL) {
        cout << temp->name << " - " << temp->score << endl;
        temp = temp->prev;
    }
}

int main() {
    int choice;
    string name;
    int score;

    while (1) {
        cout << "\n1. Add Player\n2. Delete Player\n3. Display All Players\n4. Display Lowest Score\n5. Display Same Score\n6. Display Backward From Player\n7. Exit\nEnter choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter name: ";
                cin >> name;
                cout << "Enter score: ";
                cin >> score;
                addPlayer(name, score);
                break;
            case 2:
                cout << "Enter name to delete: ";
                cin >> name;
                deletePlayer(name);
                break;
            case 3:
                displayAll();
                break;
            case 4:
                displayLowestScore();
                break;
            case 5:
                cout << "Enter score to search: ";
                cin >> score;
                displaySameScore(score);
                break;
            case 6:
                cout << "Enter name to start from: ";
                cin >> name;
                displayBackwardFrom(name);
                break;
            case 7:
                cout << "Exiting...\n";
                return 0;  
            default:
                cout << "Invalid choice!\n";
        }
    }

    return 0;
}

#include<iostream>
using namespace std;
struct Node{
	int truck_id;
	Node*next;
};
class Queue{
	Node*front;
	Node*rear;
	public:
		Queue(){
			front=NULL;
			rear=NULL;
		}
		bool isEmpty(){
			return front==NULL;
		}
		void Entergarage(int truck_id){
			Node*newNode=new Node();
			newNode->truck_id=truck_id;
			newNode->next=NULL;
			if(rear==NULL){
				front=rear=newNode;
			}else{
				rear->next=newNode;
				rear=newNode;
			}
			cout<<"Truck is on road"<<truck_id<<endl;
		}
		void Exitgargage(){
			if(isEmpty()){
				cout<<"Roard is empty"<<endl;
				return;
			}
			Node*temp=front;
			front=front->next;
			int removetruck_id=temp->truck_id;
			delete temp;
			cout<<"Truck is left from the road"<<removetruck_id<<endl;
		}
		void Showtruck(){
			if(isEmpty()){
				cout<<"Road is empty"<<endl;
				return ;
			}
			cout<<"Truck on the Road with id ";
			Node*temp=front;
			while(temp!=NULL){
				cout<<temp->truck_id<<" ";
				temp=temp->next;
			}
			cout<<endl;
		}
};
int main(){
	Queue q;
	q.Entergarage(201);
	q.Entergarage(221);
		q.Entergarage(231);
			q.Entergarage(131);
		q.Showtruck();
	q.Exitgargage();
		q.Exitgargage();
			q.Exitgargage();
				q.Exitgargage();
		q.Showtruck();
		
	return 0;
}
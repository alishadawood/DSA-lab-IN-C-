//applicant_id, height, weight, eyesight vision number and status of test
#include<iostream>
using namespace std;
struct Applicant{
	int applicant_id;
	float height;
	float weight;
	float eyesight_vision;
	string status;
	 Applicant* next;
};
class Applicantqueue{
	public:
	Applicant*front;
	Applicant*rear;
	
	Applicantqueue(){
		front=NULL;
		rear=NULL;
	}

void enqueue(int id,float h,float w,float e,string s)
{
	//applicant_id, height, weight, eyesight vision number and status of test
Applicant* newNode=new Applicant;
newNode->applicant_id=id;
newNode->height=h;
newNode->weight=w;
newNode->eyesight_vision=e;
newNode->status=s;
  newNode->next = NULL;
  if(rear==NULL){
  	front=rear=newNode;
  }
  rear->next=newNode;
  rear=newNode;
}
  void dequeu(){
  	if(front==NULL){
  		cout<<"queue is empty"<<endl;
	  }
	  Applicant*temp=front;
	  front=front->next;
	  int removeapplicant_id=temp->applicant_id;
	  float removeheight=temp->height;
	    float removeweight=temp->weight;
	     float removeeyesight_vision=temp->eyesight_vision;
	      string removestatus=temp->status;
	  //int removeData=temp->;
	  delete temp;
	  return ;
  }
  void removeSecondApplicant() {
        if (front == NULL || front->next == NULL) {
            cout << "Not enough applicants to remove the second one.\n";
            return;
        }
        Applicant* second = front->next;
        front->next = second->next;
        if (second == rear) {
        	 delete second;
            rear = front;
        }
        cout << "Second applicant removed due to urgency.\n";
    }
      void display(){
  	
  	   Applicant* temp = front;
  	   while(temp!=NULL){
  	    cout << "ID is: " << temp->applicant_id
  	    <<",Height is"<<temp->height
  	      << ", Weight is: " << temp->weight
                 << ", eyesight is: " << temp->eyesight_vision
                 << ", Test Status is: " << temp->status << endl;
            temp = temp->next;
		 }
  }

};
int main() {
    Applicantqueue aq;

    aq.enqueue(1, 4.0, 65, 1.2, "Waiting");
    aq.enqueue(2, 4.9, 70, 1.5, "Waiting");
    aq.enqueue(3, 6.0, 75, 1.1, "Waiting");
    aq.enqueue(4, 4.8, 80, 1.3, "Waiting");
    aq.enqueue(5, 5.96, 68, 1.4, "Waiting");
    aq.enqueue(6, 6.1, 90, 1.0, "Waiting");
    aq.enqueue(7, 5.5, 60, 1.6, "Waiting");
    cout<<"All Applicant Record"<<endl;
    aq.display();
    aq.removeSecondApplicant();
     cout<<"After removing Second Applicant"<<endl;
    aq.display();
      return 0;
  }

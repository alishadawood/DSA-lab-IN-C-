#include<iostream>
using namespace std;
const int MAX_SIZE = 100;
class Inventory
{
public:
    int serialNum;
    int manufactYear;
    int lotNum;
    Inventory()
	{
	serialNum = 0;
    manufactYear = 0;
    lotNum = 0;
	}
    void setData(int s, int y, int l)
	{
        serialNum = s;
        manufactYear = y;
        lotNum = l;
    }
    void display()
	{
        cout << "Serial: " << serialNum << ", Year: " << manufactYear << ", Lot: " << lotNum << endl;
    }
};
class Stack
{
private:
    Inventory stack[MAX_SIZE];
    int top;
public:
    Stack()
	{
	top = -1;
	}
    void push(Inventory part)
	{
        if (top >= MAX_SIZE - 1)
		{
            cout << "Stack is full! Cannot add more parts.\n";
            return;
        }
        stack[++top] = part;
    }
    void pop()
	{
        if (top < 0)
		{
            cout << "Stack is empty! No parts to remove.\n";
            return;
        }
        cout << "Removing Part - ";
        stack[top--].display();
    }
    void display()
	{
        if (top < 0)
		{
            cout << "Stack is empty!\n";
            return;
        }
        cout << "Current Inventory:\n";
        for (int i = top; i >= 0; i--)
		{
            stack[i].display();
        }
    }
};
int main()
{
    Stack inventoryStack;
    int choice;
    do
	{cout<<"Alisha Dawood\n59187"<<endl;
        cout << "1. Add Part"<<endl;
		cout<<"2.Remove Part"<<endl;
		cout<<"3.Show Inventory"<<endl;
		cout<<"4. Exit"<<endl;
        cout <<"5.Enter your choice: ";
        cin >> choice;
        if (choice == 1)
		{
            Inventory part;
            int serial, year, lot;
            cout << "Enter Serial Number: ";
            cin >> serial;
            cout << "Enter Manufacturing Year: ";
            cin >> year;
            cout << "Enter Lot Number: ";
            cin >> lot;
            part.setData(serial, year, lot);
            inventoryStack.push(part);
        } 
        else if (choice == 2)
		{
            inventoryStack.pop();
        } 
        else if (choice == 3)
		{
            inventoryStack.display();
        }
    } while (choice != 4);
    cout << "\nFinal Inventory:\n";
    inventoryStack.display();
    return 0;
}